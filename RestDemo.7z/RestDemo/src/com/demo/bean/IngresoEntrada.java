package com.demo.bean;

import java.util.Date;

public class IngresoEntrada {
	private String mensaje;
	private int opcObra;
	private int opcHis;
	private int opcAct;
	private int opcPueEsc;
	private String iniObra;
	public String getMensaje() {
		return mensaje;
	}
	public void setMensaje(String mensaje) {
		this.mensaje = mensaje;
	}
	public int getOpcObra() {
		return opcObra;
	}
	public void setOpcObra(int opcObra) {
		this.opcObra = opcObra;
	}
	public int getOpcHis() {
		return opcHis;
	}
	public void setOpcHis(int opcHis) {
		this.opcHis = opcHis;
	}
	public int getOpcAct() {
		return opcAct;
	}
	public void setOpcAct(int opcAct) {
		this.opcAct = opcAct;
	}
	public int getOpcPueEsc() {
		return opcPueEsc;
	}
	public void setOpcPueEsc(int opcPueEsc) {
		this.opcPueEsc = opcPueEsc;
	}
	public String getIniObra() {
		return iniObra;
	}
	public void setIniObra(String iniObra) {
		this.iniObra = iniObra;
	}

	
	
}
