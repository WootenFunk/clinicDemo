package com.demo.bean;

import java.util.Date;

public class Funcion {
	private Date fecha;
	private String  horaInicio;
	private int duracion;
	private int nroLlamados;
	private String horaInt;
	private int duracionInt;
	private double costo;
	private double precio;
	private String estado;
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public String getHoraInicio() {
		return horaInicio;
	}
	public void setHoraInicio(String horaInicio) {
		this.horaInicio = horaInicio;
	}
	public int getDuracion() {
		return duracion;
	}
	public void setDuracion(int duracion) {
		this.duracion = duracion;
	}
	public int getNroLlamados() {
		return nroLlamados;
	}
	public void setNroLlamados(int nroLlamados) {
		this.nroLlamados = nroLlamados;
	}
	public String getHoraInt() {
		return horaInt;
	}
	public void setHoraInt(String horaInt) {
		this.horaInt = horaInt;
	}
	public int getDuracionInt() {
		return duracionInt;
	}
	public void setDuracionInt(int duracionInt) {
		this.duracionInt = duracionInt;
	}
	public double getCosto() {
		return costo;
	}
	public void setCosto(double costo) {
		this.costo = costo;
	}
	public double getPrecio() {
		return precio;
	}
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	
	
}
