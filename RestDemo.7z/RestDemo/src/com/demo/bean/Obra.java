package com.demo.bean;

public class Obra {
	private int idObra;
	private String nombre;
	private String autor;
	private String año;
	private String origen;
	private String idiomaOriginal;
	private String reseñaBreve;
	private String historia;
	private String dramaturgo;
	private String director;
	private String productor;
	private String productora;
	private String asistenteDireccion;
	private String asistenteProduccion;
	private String direccion;
	private String teatro;
	private String estado;
	public int getIdObra() {
		return idObra;
	}
	public void setIdObra(int idObra) {
		this.idObra = idObra;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public String getAutor() {
		return autor;
	}
	public void setAutor(String autor) {
		this.autor = autor;
	}
	public String getAño() {
		return año;
	}
	public void setAño(String año) {
		this.año = año;
	}
	public String getOrigen() {
		return origen;
	}
	public void setOrigen(String origen) {
		this.origen = origen;
	}
	public String getIdiomaOriginal() {
		return idiomaOriginal;
	}
	public void setIdiomaOriginal(String idiomaOriginal) {
		this.idiomaOriginal = idiomaOriginal;
	}
	public String getReseñaBreve() {
		return reseñaBreve;
	}
	public void setReseñaBreve(String reseñaBreve) {
		this.reseñaBreve = reseñaBreve;
	}
	public String getHistoria() {
		return historia;
	}
	public void setHistoria(String historia) {
		this.historia = historia;
	}
	public String getDramaturgo() {
		return dramaturgo;
	}
	public void setDramaturgo(String dramaturgo) {
		this.dramaturgo = dramaturgo;
	}
	public String getDirector() {
		return director;
	}
	public void setDirector(String director) {
		this.director = director;
	}
	public String getProductor() {
		return productor;
	}
	public void setProductor(String productor) {
		this.productor = productor;
	}
	public String getProductora() {
		return productora;
	}
	public void setProductora(String productora) {
		this.productora = productora;
	}
	public String getAsistenteDireccion() {
		return asistenteDireccion;
	}
	public void setAsistenteDireccion(String asistenteDireccion) {
		this.asistenteDireccion = asistenteDireccion;
	}
	public String getAsistenteProduccion() {
		return asistenteProduccion;
	}
	public void setAsistenteProduccion(String asistenteProduccion) {
		this.asistenteProduccion = asistenteProduccion;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public String getTeatro() {
		return teatro;
	}
	public void setTeatro(String teatro) {
		this.teatro = teatro;
	}
	public String getEstado() {
		return estado;
	}
	public void setEstado(String estado) {
		this.estado = estado;
	}
	
	

}
